function [roots, num_roots] = cardano(a, b, c, d)

roots = zeros(1,3); %initialize root vec

q = (3*a*c - b^2) / (9 * a^2); %set q
r = (9*a*b*c - 27*a^2*d - 2*b^3) / (54 * a^3);%set r

D = q^3 + r^2; %calc determinant


tol = 1e-12; % set tol for 0 instead of exactly 0. almost eps should b fine

if D > tol %steps taken from Professor Servio's vapor pressure slides
    s = nthroot(r + sqrt(D), 3);
    t = nthroot(r - sqrt(D), 3);
    num_roots = 1;
    roots(1) = s + t - b/(3*a);
    roots(2) = NaN;
    roots(3) = NaN;

elseif -tol < D && D < tol
    s = nthroot(r, 3);
    t = s;
    num_roots = 3;
    roots(1) = s + t - b/(3*a);
    roots(2) = -(s + t) / 2 - b /(3*a);
    roots(3) = roots(2);

else
    num_roots = 3;
    theta = acos(r / sqrt(-q^3));
    roots(1) = 2 * sqrt(-q) * cos(theta/3) - b/(3*a);
    roots(2) = 2 * sqrt(-q) * cos((theta + 2*pi)/3) - b/(3*a);
    roots(3) = 2 * sqrt(-q) * cos((theta + 4*pi)/3) - b/(3*a);
end

end
