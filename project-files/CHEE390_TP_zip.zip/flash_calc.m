function [alpha_phase, x, y, Z_liquid, Z_vapor, f_v, f_l, K] = flash_calc(P, T, z, K, alpha_guess)


R = 8.314; % J / (mol*K)
N = 2; %number of components
k = [0 0.130 ;
    0.130 0];

%constants from Elementary Principles of Chemical Engineering Processes,
%Felder and Perry's Chemical Engineering Handbook
%first entry isobutane, second entry CO2
Tc = [408.1 304.2]; %K 
Pc = [3.64 7.383] * 1e6; %Pa
W = [0.181 0.2236]; %dimensionless

check = sum(z);

if abs(check - 1) > 1e-8
    z = z/check; %normalize z 
end

a_critical = zeros(1,N);
b_critical = zeros(1,N);

for i=1:N % calc a and b critical
    a_critical(i) = 0.45724 * R^2 * Tc(i)^2 / Pc(i);
    b_critical(i) = 0.07780 * R * Tc(i) / Pc(i);
end

k_char = zeros(1,N);

for i =1:N
    C1 = 0.37464;
    C2 = 1.54226;
    C3 = -0.26992;
    k_char(i) = C1 + C2 * W(i) + C3 * W(i)^2;
end %used in alphaPR

Tr = zeros(1,N);

for i = 1:N
    Tr(i) = T/Tc(i);
end %vector of reduced temp

alphaPR = zeros(1,N);

for i = 1:N
    alphaPR(i) = (1 + k_char(i) * (1 - sqrt(Tr(i))))^2;
end %get alpha for the PR equation

b = b_critical;
a = a_critical .* alphaPR; %get regular a and b


theta_old = 1e9; %intiailze theta for the loop
k_iter = 1;
k_max = 1000; % set max iterations so that it should always converge

while k_iter <= k_max

    P0 = 0;
    P1 = 0;
    for i = 1:N 
        P0 = P0 + z(i) * (K(i) - 1);
        P1 = P1 + z(i) / K(i);
    end
    P1 = 1 - P1;
    %find p0 p1 to determine which phase(s) were in
    if P0 * P1 <= 0
        % two phase region
        tol = 1e-6;
        maxiter = 100;
        alpha_phase = newtrm(alpha_guess, maxiter, K, z, tol, N);    
    else
        if P0 <= 0
            alpha_phase = 0; 
            %1 phase all liq
        elseif P1 >= 0
            alpha_phase = 1; 
            % 1 phase all vapor
        end
    end
    
    x = zeros(1,N);
    y = zeros(1,N);
    for i = 1:N
        x(i) = z(i) / (1 + alpha_phase * (K(i) - 1));
        y(i) = K(i) * x(i);
    end
    
    sumx = sum(x);
    sumy = sum(y);
    %normalize
    for i = 1:N
        x(i) = x(i) / sumx ; 
        y(i) = y(i) / sumy ;
    end
    
    %calc b vapor and b liq
    b_vap = 0;
    b_liq = 0;
    for i = 1:N
        b_vap = b_vap + y(i) * b(i);
        b_liq = b_liq + x(i) * b(i);
    end
    
    
    a_vap = 0;
    a_liq = 0;
    %calc a vapor and a liq
    for i = 1:N
        for j = 1:N
            a_vap = a_vap + y(i) * y(j) * sqrt(a(i)) * sqrt(a(j)) * (1-k(i,j));
            a_liq = a_liq + x(i) * x(j) * sqrt(a(i)) * sqrt(a(j)) * (1-k(i,j));
        end
    end
    
    A_vap = a_vap * P / (R^2 * T^2);
    B_vap = b_vap * P / (R*T);
    
    a_cardano_v = 1;
    b_cardano_v = -1 * (1-B_vap);
    c_cardano_v = (A_vap - 3*B_vap^2 - 2*B_vap);
    d_cardano_v = -1 * (A_vap*B_vap - B_vap^2 - B_vap^3);
    
    %vapor phase
    [Z_roots_v, ~] = cardano(a_cardano_v, b_cardano_v, c_cardano_v, d_cardano_v);
    if isnan(Z_roots_v(2)) || (isnan(Z_roots_v(3)))
        Z_vapor = Z_roots_v(1);
        %V_vapor = Z_vapor * R * T / P;
    else
        Z_roots_v = Z_roots_v(Z_roots_v > 0); %ensures only positive roots taken
        Z_vapor = max(Z_roots_v); % only take max root cause were vapor
        %V_vapor = Z_vapor * R * T / P; %don't actually need V
    end
    
    %same for liq phase
    A_liq = a_liq * P / (R^2 * T^2);
    B_liq = b_liq * P / (R*T);
    
    a_cardano_l = 1;
    b_cardano_l = -1 * (1-B_liq);
    c_cardano_l = (A_liq - 3*B_liq^2 - 2*B_liq);
    d_cardano_l = -1 * (A_liq*B_liq - B_liq^2 - B_liq^3);
    
    [Z_roots_l, ~] = cardano(a_cardano_l, b_cardano_l, c_cardano_l, d_cardano_l);
    if isnan(Z_roots_l(2)) || (isnan(Z_roots_l(3)))
        Z_liquid = Z_roots_l(1);
        %V_liquid = Z_liquid * R * T / P;
    else 
        Z_roots_l = Z_roots_l(Z_roots_l > 0); %ensures only positive roots taken
        Z_liquid = min(Z_roots_l); % only take min root cause were liquid
        %V_liquid = Z_liquid * R * T / P; 
    end
    
    
    f_v = zeros(1,N);
    f_l = zeros(1,N);
    
    for i = 1:N
        %vapor so composition is y, Z is Z_vapor
        f_v(i) = fugacity(Z_vapor, y, a, b, a_vap, b_vap, A_vap, B_vap, k, P, N, i);
    
        %liquid so composition is x, Z is Z_liquid
        f_l(i) = fugacity(Z_liquid, x, a, b, a_liq, b_liq, A_liq, B_liq, k, P, N, i);
    end
    
    %theta calc.
    theta = 0;
    for i = 1:N
        theta = theta + y(i) * log( f_v(i) / f_l(i) );
    end

    if k_iter == 1
    %skip test, update K
    else
        % thetas converged?
        if abs(theta - theta_old) <= 1e-8
            %if yes, check sign
            if theta > 0
                % feed is liq, check alpha
                if abs(alpha_phase) < 1e-8 % alpha is 0,  good
                    disp('converged, feed is liquid like and alpha ~ 0')
                end
            else
                % theta <= 0 so feed is vapor like so check alpha
                if abs(alpha_phase - 1) < 1e-8 %alpha is 1, good
                    disp('converged, feed is vapor like and alpha ~ 1')
                end
            end

            % print and exit
            fprintf('theta = %.3e after %d iterations\n', theta, k_iter);
            break
        end
    end

    % did not converge, update K factors
    gamma = 1; % use g = 1

    for i = 1:N
        K(i) = K(i) * (f_l(i) / f_v(i))^gamma;
    end
    % should be 2 phase
    % store theta for next iteration and increment k
    if k_iter <= k_max
        theta_old = theta;
        k_iter    = k_iter + 1;
    else
        disp('did not converge :(')
        break
    end

end 
end


function f = fugacity(Z, x, a, b, a_mix, b_mix, A, B, k, P, N, component)
%x = comp, a and b from eq. 20, 21
%k, P T R N given
%component is the i value in the big loops
aij   = zeros(N,N);
for i = 1:N %since i didn't save aij as a variable we have to get it again
    for j = 1:N
        aij(i,j) = (1 - k(i,j)) * sqrt(a(i) * a(j));  
    end
end

summation = 0; 
for i = 1:N
    summation = summation + x(i) * aij(component, i);
end
%followed directly from PR paper
term1 = (b(component) / b_mix) * (Z - 1);
term2 = -log(Z - B);
term3 = -A / (2 * sqrt(2) * B);
term4 = 2*(summation / a_mix) - b(component)/b_mix;
termlog = log( (Z + 2.414*B) / (Z - 0.414*B) );

lnphi = term1 + term2 + term3 * term4 * termlog;
f = exp(lnphi) * x(component) * P;

end



function alpha_phase = newtrm(alpha_phase, maxiter, K, z, tol, N)
%new newton raphson loop to take on correct paramaters for the TP
for iter = 1:maxiter
        P_alpha = 0;
        dP_alpha = 0;

        for i = 1:N
            denom = 1 + alpha_phase * (K(i) - 1);
            P_alpha  = P_alpha  + z(i) * (K(i) - 1) / denom;
            dP_alpha = dP_alpha - z(i) * (K(i) - 1)^2 / denom^2; %derivative of R-R eq.
        end

        alpha_new = alpha_phase - P_alpha / dP_alpha ;  %newtn raphson step
        
        if abs(alpha_new - alpha_phase) < tol %if we converge break loop
            alpha_phase = alpha_new;
            break
        end

        alpha_phase = alpha_new; %update guess
end
end

