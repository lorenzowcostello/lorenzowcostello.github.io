clear
clc

T = 310.93;%K
N = 2; %2 components

%component data for initial Wilson K
Tc = [408.1 304.2]; %K
Pc = [3.64 7.383] * 1e6; %Pa
W  = [0.181 0.2236]; %dimensionless

%start with nearly pure isobutane, but not exacty since we know the first
% point (vap. pressure of isob.)
z2 = 1e-8;
z  = [1 - z2, z2];

% starting pressure is Psat of isobutane at 310.93 K
P  = 501008.200266; %in Pa, found via perrys chemical enigneering 8th ed.
dP = 1e4; %step for pressure (pa)
dz = 0.01; %step for mol frac

iter = 643; % set max points, played with it until it look good
P_vec  = zeros(1,iter+1); %create vectors
x2_vec = zeros(1,iter+1);
y2_vec = zeros(1,iter+1); % add 1 bc we manually put in last point

P_vec(1) = P; %manually put it first point, we know it to be isobutane Pvap
x2_vec(1) = 0;
y2_vec(1) = 0;

P_vec(end) = 6940 * 1000; %manually put in last point to close the 2 lines
x2_vec(end) = 0.882;
y2_vec(end) = 0.882;

%initial guesses for first iteration
K = zeros(1,N);
for i = 1:N
    K(1,i) = wilson(T, P, Tc(i), Pc(i), W(i));
end
alpha = 0.5;  % initial vapor fraction guess

%first flash, then afterwards use zero order cont.
[alpha_phase, x, y, Z_liq, Z_vap, f_v, f_l, K] = flash_calc(P, T, z, K, alpha);

% use returned alpha as the starting guess for continuation
alpha = alpha_phase;

i = 2; %start at 2, since we know first already


while i <= iter %don't go to end of vector since we manually put it in
    % zero-order continuation so use previous K and alpha as guesses
    [alpha_phase, x, y, Z_liq, Z_vap, f_v, f_l, K] = flash_calc(P, T, z, K, alpha);
    %zero was giving me problems, set tol insteaed
    tol = 1e-6;

    if alpha_phase > tol && alpha_phase < 1 - tol
        %we are in 2 phase region
        P_vec(i)  = P; %set P
        x2_vec(i) = x(2); %take equilibrium fractions
        y2_vec(i) = y(2);

        P = P + dP; %update P and continue loop
        i = i + 1;

    elseif alpha_phase <= tol
        %only liquid, step up the z guess and do NOT update vectors
        z2 = z2 + dz;
        if z2 >= 1
            break; %will get normalized in next loop
        end
        z = [1 - z2, z2]; % update z for next loop
    else 
        % only vapor step up the P guess and do NOT update vec
        P = P + dP;
    end

    % update alpha guess for the next loop
    alpha = alpha_phase;
end

P_kPa = P_vec/1000; % correct units to match fig 1

figure;
plot(x2_vec, P_kPa, 'LineWidth', 1.5); hold on;
plot(y2_vec, P_kPa, 'LineWidth', 1.5);

xlabel('Mole Fraction CO_2 (x_2, y_2, z_2)');
ylabel('Pressure [kPa]');
title('Pressure vs. Mole Fraction at T = 310.93 K');
legend('x_{CO_2}','y_{CO_2}','Location','NorthWest');
xlim([0 1]);
ylim([0 8000])
grid on;
