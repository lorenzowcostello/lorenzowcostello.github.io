function Ki = wilson(T, P, Tc_i, Pc_i, W_i)
lnKi = log(Pc_i/P) + 5.37*(1+W_i)*(1-Tc_i/T);
Ki = exp(lnKi);
end